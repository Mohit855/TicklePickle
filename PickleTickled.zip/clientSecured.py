import os
import pickle

class MAC():
    def getMac(safecode,key):
        mac = 0
        for char in safecode:
            mac = mac + (ord(char)+key)
        return mac

class Example:
    def __init__(self, command):
        self.command = command

    def __reduce__(self):
        return (os.system, (self.command,))

def fun(name,password):
    s = {"username":name,"password":password}
    safecode = pickle.dumps(s)
    mac = MAC.getMac((safecode), 10)   #key = 10
    with open("users.json","wb") as f:
        f.write(safecode, mac)
    return safecode, mac

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    yo_fun = fun(u,p)
    
