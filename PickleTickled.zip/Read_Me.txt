
How to Tickle the Pickle

Description : You are given 2 files namely client.py, server.py. A vulnerability exists in these files. Your aim is to do the following

1.    Find out what the vulnerability is.
2.    Create a exploit code so that you can exploit the working of the application.
3.    Modify both the files in such a way that the application is no more vulnerarble.


Answers -

1.   Vulnerability  - Insecure Deserialisation due to use of Python Pickle Module
                    - Categorised under A08:2021 – Software and Data Integrity Failures of OWASP Top 10 - 2021
                    - RCE

2.  

