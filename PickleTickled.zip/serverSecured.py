import os
import pickle

def reverse_fun():
      with open("users.json","rb") as f:
          data = f.read()
      
      d = pickle.loads(data)
      return d

if __name__ == '__main__':
    if mac == get.MAC(str(data), 10):
        print(reverse_fun())

    else:
        print('Deserialisation not authorised')
        print('Data integrity questionable')
